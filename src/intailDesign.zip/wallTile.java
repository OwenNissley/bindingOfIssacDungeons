public class wallTile extends tile{
    /**
     * Constructor to supply symbol
     */
    wallTile(){
        super('s');

    }
}
