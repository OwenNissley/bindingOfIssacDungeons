public class emptyTile extends tile{
    /**
     * Constructor to supply symbol
     */
    emptyTile(){
        super(' ');
    }
}
