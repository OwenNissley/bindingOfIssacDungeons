public class doorTile extends tile{
    /**
     * Constructor to supply symbol
     */
    doorTile(){
        super(' ');
    }
}
