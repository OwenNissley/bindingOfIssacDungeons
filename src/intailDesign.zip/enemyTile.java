public class enemyTile extends tile{
    /**
     *
     * @param symbol
     * Supplies symbol
     */
    enemyTile(char symbol){
        super(symbol);
    }
}
