public class item {
    private String name;
    private String effect;
    private int health;
    private int strength;

    /**
     *
     * @param Name
     * @param effect
     * @param health
     * @param strength
     * Update local variables accordingly
     */
    item( String Name, String effect, int health, int strength){

    }


    /**
     * Updates players stats accordingly
     */
    public void use(){

    }

    public int getHealth() {
        return health;
    }

    public String getName() {
        return name;
    }

    public int getStrength() {
        return strength;
    }

    public String getEffect() {
        return effect;
    }





}
