import java.lang.reflect.Array;
import java.util.ArrayList;

public class player {
    private int health;
    private int damage;
    private ArrayList<item> inventory;

    /**
     * Create items and add to inventory and set health and damage
     */
    player(){

    }

    /**
     * Add Item to item inventory
     * @param Item
     */
    public void addItem(item Item){

    }

    /**
     * supplies players move for room to use
     * @param Move
     */
    public void getMove(char Move){

    }

    /**
     * provides input for room to use
     *
     */
    public void action(){

    }

    
}
