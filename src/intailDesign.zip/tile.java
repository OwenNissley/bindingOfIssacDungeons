public abstract class tile {

    //The thing it is going to display
    private char symbol;

    /**
     * @param symbol
     * Supplies symbol
     */
    tile(char symbol){
        this.symbol = symbol;

    }

    public char getSymbol() {
        return symbol;
    }

}
