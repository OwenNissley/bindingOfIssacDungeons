public class itemTile extends tile{
    /**
     * Constructor to supply symbol
     */
    itemTile(char symbol){
        super(symbol);
    }
}
