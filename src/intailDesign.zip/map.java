import java.util.LinkedList;
import java.util.Queue;

public class map {
    //Keep tract of rooms
    private Queue<room> rooms = new LinkedList<>();

    /**
     * Will generate list of rooms via newRoom and fill Queue
     */
    map(){

    }

    /**
     * Supply next room for list
     * @return
     */
    public room getNextRoom(){
        return null;
    }

}
