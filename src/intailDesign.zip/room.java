import java.util.ArrayList;
import java.util.Collection;

public class room {
    private ArrayList<tile> tiles;
    private int posX;
    private int posY;

    /**
     * Tell what room to create  and create
     * @param type
     */
    room(String type){

    }

    /**
     * Make tile empty
     */
    public void updateTile(){

    }
    /**
     * Takes postion of player and updates accordingly
     */
    public void playerActAt(){

    }

    /**
     * display room with player
     */
    public void print(){

    }

    /**
     * Puts player to next room if walked through door
     */
    public void toNewRoom(){

    }
}
